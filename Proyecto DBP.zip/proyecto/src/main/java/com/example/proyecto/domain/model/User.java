package com.example.proyecto.domain.model;

public class User {
    
}
