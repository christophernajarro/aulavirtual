package com.example.proyecto.dto;

public class RegisterDTO {
    
}
