package com.example.proyecto.infrastructure.config;

public class WebSecurityConfig {
    
}
