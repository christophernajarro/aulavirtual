package com.example.proyecto.infrastructure.controller;

public class AuthController {
    
}
