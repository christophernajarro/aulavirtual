package com.example.proyecto.domain.model;

public class Role {
    
}
