import React from 'react';
import './App.css';
import PantallaPrincipal from './PantallaPrincipal'; // Asegúrate de que la ruta sea correcta

function App() {
  return (
    <div className="App">
      <PantallaPrincipal />
    </div>
  );
}

export default App;
